# DEPRECATED
# This file contains the legacy local kernel execution logic which has been removed
# to enforce the strict Sandbox Policy (no arbitrary user code execution on backend).
#
# Please use app.py instead, which provides the secure Arxiv Search and Simulation API.
#
# To run the backend:
# uvicorn app:app --reload --port 8000
