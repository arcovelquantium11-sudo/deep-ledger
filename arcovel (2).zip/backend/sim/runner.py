from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Literal, Optional
import math
import numpy as np


ModelName = Literal["harmonic_oscillator"]


@dataclass(frozen=True)
class HarmonicOscillatorParams:
    """
    Simple driven/undriven oscillator:
      x'' + 2ζω x' + ω^2 x = 0
    """
    x0: float = 1.0
    v0: float = 0.0
    omega: float = 2.0 * math.pi  # rad/s
    zeta: float = 0.02            # damping ratio
    t_end: float = 5.0            # seconds
    dt: float = 0.001             # seconds


def _simulate_harmonic_oscillator(p: HarmonicOscillatorParams) -> Dict[str, Any]:
    n = int(p.t_end / p.dt) + 1
    t = np.linspace(0.0, p.t_end, n)

    x = np.zeros(n, dtype=float)
    v = np.zeros(n, dtype=float)

    x[0] = p.x0
    v[0] = p.v0

    # Semi-implicit Euler (stable-ish for small dt); replace with RK4 later if desired.
    for i in range(1, n):
        a = -2.0 * p.zeta * p.omega * v[i - 1] - (p.omega ** 2) * x[i - 1]
        v[i] = v[i - 1] + a * p.dt
        x[i] = x[i - 1] + v[i] * p.dt

    # Basic derived metrics
    x_rms = float(np.sqrt(np.mean(x**2)))
    x_peak = float(np.max(np.abs(x)))

    return {
        "t": t.tolist(),
        "x": x.tolist(),
        "v": v.tolist(),
        "metrics": {
            "x_rms": x_rms,
            "x_peak": x_peak,
            "n_steps": n,
        },
    }


def run_simulation(model: ModelName, params: Dict[str, Any]) -> Dict[str, Any]:
    """
    SAFE RUNNER:
    - Executes only known models.
    - Params are validated/coerced into dataclasses.
    """
    if model == "harmonic_oscillator":
        # Filter params to only those accepted by the dataclass
        valid_keys = HarmonicOscillatorParams.__dataclass_fields__.keys()
        filtered_params = {k: v for k, v in params.items() if k in valid_keys}
        p = HarmonicOscillatorParams(**filtered_params)
        return _simulate_harmonic_oscillator(p)

    raise ValueError(f"Unknown model: {model}")
