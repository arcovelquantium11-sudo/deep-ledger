export type ArxivPaper = {
  id: string;
  title: string;
  authors: string[];
  summary: string;
  published: string;
  updated?: string;
  pdf_url?: string;
  primary_category?: string;
};

export async function arxivSearch(baseUrl: string, q: string, start = 0, maxResults = 25) {
  const url = new URL(`${baseUrl}/api/arxiv/search`);
  url.searchParams.set("q", q);
  url.searchParams.set("start", String(start));
  url.searchParams.set("max_results", String(maxResults));

  const res = await fetch(url.toString());
  if (!res.ok) {
    const msg = await res.text();
    throw new Error(`arxivSearch failed: ${msg}`);
  }
  return res.json() as Promise<{
    query: string;
    start: number;
    max_results: number;
    total_results?: number;
    entries: ArxivPaper[];
  }>;
}
