```markdown
## Adding the FastAPI backend (local dev)

Quick start:

1. From repo root, create `backend/` and add the files.
2. Run locally (in backend/):
   ```
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   uvicorn app:app --reload --port 8000
   ```
3. Test:
   - GET http://localhost:8000/health
   - POST http://localhost:8000/api/run_sim
   - GET  http://localhost:8000/api/arxiv/search?q=all:graphene&start=0&max_results=5

Frontend:
- Set an API base (e.g. VITE_API_BASE=http://localhost:8000) and call the service stubs in frontend/src/services/.
```