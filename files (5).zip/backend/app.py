from __future__ import annotations

import os
import re
from typing import Any, Dict, List, Literal, Optional

import httpx
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from sim.runner import run_simulation

ARXIV_API = "http://export.arxiv.org/api/query"


# -----------------------------
# Config
# -----------------------------
def _env_list(name: str, default: List[str]) -> List[str]:
    raw = os.getenv(name, "").strip()
    if not raw:
        return default
    # comma-separated list
    return [x.strip() for x in raw.split(",") if x.strip()]

ALLOWED_ORIGINS = _env_list(
    "CORS_ORIGINS",
    ["http://localhost:5173", "http://localhost:3000"],
)

app = FastAPI(title="Deep Ledger Backend", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# -----------------------------
# Models
# -----------------------------
ModelName = Literal["harmonic_oscillator"]


class RunSimRequest(BaseModel):
    model: ModelName = Field(..., description="Predefined model name")
    params: Dict[str, Any] = Field(default_factory=dict, description="Model parameters")


class RunSimResponse(BaseModel):
    model: ModelName
    result: Dict[str, Any]


class ArxivPaper(BaseModel):
    id: str
    title: str
    authors: List[str]
    summary: str
    published: str
    updated: Optional[str] = None
    pdf_url: Optional[str] = None
    primary_category: Optional[str] = None


class ArxivSearchResponse(BaseModel):
    query: str
    start: int
    max_results: int
    total_results: Optional[int] = None
    entries: List[ArxivPaper]


# -----------------------------
# Helpers: arXiv Atom parsing
# -----------------------------
def _strip(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()


def _extract_tag(text: str, tag: str) -> Optional[str]:
    m = re.search(rf"<{tag}[^>]*>(.*?)</{tag}>", text, flags=re.DOTALL)
    if not m:
        return None
    return _strip(re.sub(r"<[^>]+>", "", m.group(1)))


def _extract_all(text: str, tag: str) -> List[str]:
    out = []
    for m in re.finditer(rf"<{tag}[^>]*>(.*?)</{tag}>", text, flags=re.DOTALL):
        out.append(_strip(re.sub(r"<[^>]+>", "", m.group(1))))
    return out


def _extract_pdf_link(entry_xml: str) -> Optional[str]:
    m = re.search(
        r'<link[^>]+type="application/pdf"[^>]+href="([^"]+)"',
        entry_xml,
        flags=re.IGNORECASE,
    )
    return m.group(1) if m else None


def _extract_primary_category(entry_xml: str) -> Optional[str]:
    m = re.search(r'<arxiv:primary_category[^>]+term="([^"]+)"', entry_xml)
    return m.group(1) if m else None


def _parse_arxiv_atom(atom_xml: str) -> Dict[str, Any]:
    total = None
    m_total = re.search(r"<opensearch:totalResults[^>]*>(\d+)</opensearch:totalResults>", atom_xml)
    if m_total:
        total = int(m_total.group(1))

    entries: List[ArxivPaper] = []
    for em in re.finditer(r"<entry>(.*?)</entry>", atom_xml, flags=re.DOTALL):
        entry = em.group(1)
        pid = _extract_tag(entry, "id") or ""
        title = _extract_tag(entry, "title") or ""
        summary = _extract_tag(entry, "summary") or ""
        published = _extract_tag(entry, "published") or ""
        updated = _extract_tag(entry, "updated")
        authors = _extract_all(entry, "name")
        pdf = _extract_pdf_link(entry)
        cat = _extract_primary_category(entry)

        entries.append(
            ArxivPaper(
                id=pid,
                title=title,
                authors=authors,
                summary=summary,
                published=published,
                updated=updated,
                pdf_url=pdf,
                primary_category=cat,
            )
        )

    return {"total_results": total, "entries": entries}


# -----------------------------
# Routes
# -----------------------------
@app.get("/health")
def health() -> Dict[str, str]:
    return {"status": "ok"}


@app.post("/api/run_sim", response_model=RunSimResponse)
def api_run_sim(req: RunSimRequest) -> RunSimResponse:
    try:
        result = run_simulation(req.model, req.params)
        return RunSimResponse(model=req.model, result=result)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/api/arxiv/search", response_model=ArxivSearchResponse)
async def api_arxiv_search(
    q: str = Query(..., description="Search query, e.g. 'all:graphene AND cat:cond-mat.mes-hall'"),
    start: int = Query(0, ge=0),
    max_results: int = Query(25, ge=1, le=100),
) -> ArxivSearchResponse:
    params = {"search_query": q, "start": str(start), "max_results": str(max_results)}
    try:
        async with httpx.AsyncClient(timeout=20.0) as client:
            r = await client.get(ARXIV_API, params=params)
            r.raise_for_status()
            parsed = _parse_arxiv_atom(r.text)
            return ArxivSearchResponse(
                query=q,
                start=start,
                max_results=max_results,
                total_results=parsed["total_results"],
                entries=parsed["entries"],
            )
    except httpx.HTTPError as e:
        raise HTTPException(status_code=502, detail=f"arXiv request failed: {e}")