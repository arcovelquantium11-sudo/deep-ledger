from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Literal
import math
import numpy as np
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ModelName = Literal["harmonic_oscillator"]

ARTIFACTS_DIR = os.path.join(os.path.dirname(__file__), "..", "artifacts")
os.makedirs(ARTIFACTS_DIR, exist_ok=True)


@dataclass(frozen=True)
class HarmonicOscillatorParams:
    x0: float = 1.0
    v0: float = 0.0
    omega: float = 2.0 * math.pi
    zeta: float = 0.02
    t_end: float = 5.0
    dt: float = 0.001


def _simulate_harmonic_oscillator(p: HarmonicOscillatorParams) -> Dict[str, Any]:
    n = int(p.t_end / p.dt) + 1
    t = np.linspace(0.0, p.t_end, n)

    x = np.zeros(n, dtype=float)
    v = np.zeros(n, dtype=float)

    x[0] = p.x0
    v[0] = p.v0

    for i in range(1, n):
        a = -2.0 * p.zeta * p.omega * v[i - 1] - (p.omega ** 2) * x[i - 1]
        v[i] = v[i - 1] + a * p.dt
        x[i] = x[i - 1] + v[i] * p.dt

    x_rms = float(np.sqrt(np.mean(x**2)))
    x_peak = float(np.max(np.abs(x)))

    # Save plot artifact
    fname = os.path.join(ARTIFACTS_DIR, f"harmonic_oscillator_{int(p.t_end*1000)}ms.png")
    plt.figure(figsize=(6,3))
    plt.plot(t, x)
    plt.title("Harmonic oscillator")
    plt.xlabel("t")
    plt.ylabel("x(t)")
    plt.tight_layout()
    plt.savefig(fname)
    plt.close()

    return {
        "t": t.tolist(),
        "x": x.tolist(),
        "v": v.tolist(),
        "metrics": {
            "x_rms": x_rms,
            "x_peak": x_peak,
            "n_steps": n,
        },
        "artifacts": [fname],
    }


def run_simulation(model: ModelName, params: Dict[str, Any]) -> Dict[str, Any]:
    if model == "harmonic_oscillator":
        p = HarmonicOscillatorParams(**params)
        return _simulate_harmonic_oscillator(p)
    raise ValueError(f"Unknown model: {model}")