export type ModelName = "harmonic_oscillator";

export type RunSimRequest = {
  model: ModelName;
  params: Record<string, any>;
};

export async function runSim(baseUrl: string, req: RunSimRequest) {
  const res = await fetch(`${baseUrl}/api/run_sim`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(req),
  });

  if (!res.ok) {
    const msg = await res.text();
    throw new Error(`runSim failed: ${msg}`);
  }
  return res.json();
}